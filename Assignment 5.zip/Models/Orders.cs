using System;
using System.ComponentModel.DataAnnotations;

namespace Customer.Models
{
    public class Order
    {
        public int ID {get; set;}
        public string Name {get; set;}
        [DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }
        public string Item {get; set;}
    }
}
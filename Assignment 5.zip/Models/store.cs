using System;
using System.ComponentModel.DataAnnotations;

namespace Customer.Models
{
    public class Store
    {
        public int ID {get; set;}
        public string StoreName {get; set;}

        [DataType(DataType.Date)]
        public DateTime StoreOrderDate { get; set; }
    }
}
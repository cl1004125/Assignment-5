﻿using System;


//prototype test to make sure a product added has an ID greater than 0.

namespace Product.Adding
{
    public class ProductAdding
    {
            public bool IsProduct(int candidate)
        {
            if (candidate == 0 ){
                return false;
            }
            throw new NotImplementedException("Not implemented.");
        }
    }
}

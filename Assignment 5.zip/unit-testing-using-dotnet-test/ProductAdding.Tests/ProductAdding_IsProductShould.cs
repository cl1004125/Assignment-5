using System;
using Xunit;
using Product.Adding;


//prototype test to make sure a product added has an ID greater than 0.

namespace Product.UnitTests.Addings
{
    public class ProductAdding_IsProductShould{
        [Fact]
        public void IsProduct_InputIs0_ReturnFalse()
        {
            var productAdded = new ProductAdding();
            bool result = productAdded.IsProduct(0);

            Assert.False(result, "Product ID should not be 0");
        }
    }
}